package org.backend.services;

import jakarta.transaction.Transactional;
import org.backend.models.Application;
import org.backend.repositories.ApplicationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

@Service
public class ApplicationService {

    @Autowired
    private ApplicationRepository applicationRepository;

    @Transactional
    public List<Application> getApplications() {
        return applicationRepository.findAll();
    }

    @Transactional
    public void saveApplication(Application application) {
        applicationRepository.save(application);
    }

    @Transactional
    public void deleteApplication(Integer applicationId) {
        applicationRepository.deleteById(applicationId);
    }

    @Transactional
    public Application getApplicationById(Integer applicationId) {
        return applicationRepository.findById(applicationId).get();
    }

    @Transactional
    public List<Application> getApplicationByPolitisID(Integer politis_id) {
        return applicationRepository.findByPolitis_Id(politis_id);
    }

    @Transactional
    public List<Application> getApplicationByIatrosID(Integer iatros_id) {
        return applicationRepository.findByIatros_Id(iatros_id);
    }

    @Transactional
    public void setStatus(Integer applicationId, String status) {
        Optional<Application> optionalApplication = applicationRepository.findById(applicationId);

        if (optionalApplication.isPresent()) {
            Application application = optionalApplication.get();
            application.setStatus(status);
            applicationRepository.save(application);
        } else {
            throw new NoSuchElementException("Application with ID " + applicationId + " not found");
        }
    }

    @Transactional
    public List<Application> getApplicationsByStatus(String status) {
        return applicationRepository.findByStatus(status);
    }
}
