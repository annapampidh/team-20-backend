package org.backend.models;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

@Entity
@Table(name = "application")
public class Application {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @NotBlank
    @Size(max = 150)
    private String status;

    @OneToOne(cascade = {CascadeType.DETACH,
            CascadeType.MERGE, CascadeType.PERSIST, CascadeType.REFRESH})
    @JoinColumn(name="politis_id")
    private User politis;

    @ManyToOne(cascade = {CascadeType.DETACH,
            CascadeType.MERGE, CascadeType.PERSIST, CascadeType.REFRESH})
    @JoinColumn(name="iatros_id")
    private User iatros;

    public Application() {
    }

    public Application(User politis, User iatros) {
        this.politis = politis;
        this.iatros = iatros;
    }

    public User getPolitis() {
        return politis;
    }

    public void setPolitis(User politis) {
        this.politis = politis;
    }

    public User getIatros() {
        return iatros;
    }

    public void setIatros(User iatros) {
        this.iatros = iatros;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "RequestForApproval{" +
                "id=" + id +
                ", politis=" + politis +
                ", iatros=" + iatros +
                ", status=" + status +
                '}';
    }
}
