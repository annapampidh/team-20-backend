package org.backend.repositories;

import org.backend.models.Application;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
@Repository
public interface ApplicationRepository extends JpaRepository<Application, Integer> {

    List<Application> findById(int applicationId);
    List<Application> findByStatus(String status);

    List<Application> findByPolitis_Id(Integer politisId);

    List<Application> findByIatros_Id(Integer iatrosId);

}
