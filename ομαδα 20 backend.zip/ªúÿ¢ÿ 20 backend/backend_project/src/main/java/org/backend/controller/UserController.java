package org.backend.controller;

import org.backend.models.User;
import org.backend.services.UserDetailsServiceImpl;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.util.List;

@RestController
@CrossOrigin(origins = "*", maxAge = 3600)
@RequestMapping("/api/users")
public class UserController {

    private final UserDetailsServiceImpl userService;

    public UserController(UserDetailsServiceImpl userService) {
        this.userService = userService;
    }

    @GetMapping("")
    @PreAuthorize("hasAuthority('admin')")
    public List<User> allUsers() {
        return userService.all();
    }

    @GetMapping("/{id}")
    public User findById(@PathVariable int id) { return userService.findSpecificUserById(id); }

    @PutMapping("")
    @PreAuthorize("hasAnyAuthority('host', 'admin', 'user')")
    public ResponseEntity<?> updateUser(Principal principal, @RequestBody User userDTO) {
        User user = userService.findByUsername(principal.getName());
        if (user.getRoles().stream().findFirst().isPresent() && (userDTO.getId() == user.getId() || user.getId() ==1) ){
            return ResponseEntity.ok().body(userService.registerUser(userDTO));
        }
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Failed to update user");
    }

    @PostMapping("/register")
    @PreAuthorize("hasAuthority('admin')")
    public ResponseEntity<?> registerUser(@RequestBody User userDTO) {
        User registeredUser = userService.registerUser(userDTO);
        return ResponseEntity.ok().body(registeredUser);
    }

}
