# Java Spring Backend API Deployment Guide

This guide will help you deploy the Java Spring backend API using IntelliJ IDEA. The backend is developed in Java 17 and is a Maven project with a `pom.xml` file. The API is located in the `controllers` package, and the main Java file serves as the starting point for deploying the backend.

## Prerequisites

- [Java Development Kit (JDK) 17]
- [IntelliJ IDEA]
- [SQLite Database Browser]


## Running the Backend
Open the project in IntelliJ IDEA.
Navigate to the Main.java file.
Run the main method to start the backend.
The backend API should now be running, and you can access it at http://localhost:9000.


## Database Setup

Note that the database has been already populated with data. 

If you want to re-populate it, then open your SQLite database editor and execute the following SQL script to create tables and populate sample data:


```sql
-- Initialize the Users table
DROP TABLE IF EXISTS users;

CREATE TABLE IF NOT EXISTS users (
    id         INTEGER PRIMARY KEY,
    email      VARCHAR(50),
    password   VARCHAR(50),
    username   VARCHAR(20)
);

INSERT INTO users (id, email, password, username)
VALUES (1, 'admin@admin.admin', '123', 'admin');

INSERT INTO users (id, email, password, username)
VALUES (2, 'politis1@politis.politis', '123', 'politis1');

INSERT INTO users (id, email, password, username)
VALUES (3, 'iatros1@iatros.iatros', '123', 'iatros1');

-- Initialize the Application table
DROP TABLE IF EXISTS application;

CREATE TABLE IF NOT EXISTS application (
    id         INTEGER PRIMARY KEY,
    politis_id INTEGER NOT NULL,
    iatros_id  INTEGER NOT NULL,
    status     VARCHAR(20),
    FOREIGN KEY (politis_id) REFERENCES users(id),
    FOREIGN KEY (iatros_id) REFERENCES users(id)
);

INSERT INTO application (id, politis_id, iatros_id, status)
VALUES (1, 2, 3, 'PENDING');

-- Initialize the Roles table
DROP TABLE IF EXISTS roles;

CREATE TABLE IF NOT EXISTS roles (
    id   INTEGER PRIMARY KEY,
    name VARCHAR(20)
);

INSERT INTO roles (id, name)
VALUES (1, 'ROLE_ADMIN');

INSERT INTO roles (id, name)
VALUES (2, 'ROLE_POLITIS');

INSERT INTO roles (id, name)
VALUES (3, 'ROLE_IATROS');

-- Initialize the UserRoles table
DROP TABLE IF EXISTS user_roles;

CREATE TABLE IF NOT EXISTS user_roles (
    user_id INTEGER NOT NULL,
    role_id INTEGER NOT NULL,
    PRIMARY KEY (user_id, role_id),
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (role_id) REFERENCES roles(id)
);

INSERT INTO user_roles (user_id, role_id)
VALUES (1, 1);

INSERT INTO user_roles (user_id, role_id)
VALUES (2, 2);

INSERT INTO user_roles (user_id, role_id)
VALUES (3, 3);

PRAGMA foreign_keys = ON;'''




